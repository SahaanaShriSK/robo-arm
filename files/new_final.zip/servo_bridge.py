import serial
import time
import math
from inverse_kinematics import solve_ik

# 🔴 CHANGE IF COM PORT CHANGES
SERIAL_PORT = "COM8"
BAUD_RATE = 115200

# ===== ARM CALIBRATION (TUNE THESE) =====
SCALE   = 22.0   # letter size (meters → cm)
Y_FIXED = 9.0    # distance of paper from base (cm)
MAX_R   = 12.5   # max reachable radius (cm)

WRITE_Z = 2.4    # pen touching paper
LIFT_Z  = 6.0    # pen lifted

# ========================================

ser = None  # global serial object


def init_serial():
    global ser
    if ser is None:
        ser = serial.Serial(SERIAL_PORT, BAUD_RATE, timeout=1)
        time.sleep(2)
        print("[SERIAL] Connected to ESP32")


def send_angles(theta0, theta1, theta2):
    global ser

    if ser is None:
        init_serial()

    base = int(math.degrees(theta0)) + 90
    shoulder = int(math.degrees(theta1)) + 90
    elbow = int(math.degrees(theta2)) + 90

    # ===== SAFE SERVO LIMITS =====
    base     = max(30, min(150, base))
    shoulder = max(40, min(140, shoulder))
    elbow    = max(30, min(150, elbow))
    # =============================

    cmd = f"{base},{shoulder},{elbow}\n"
    ser.write(cmd.encode())
    time.sleep(0.08)   # slow & safe


# ===== MAIN DRAW FUNCTION =====
def draw_waypoints(waypoints):
    init_serial()

    print(f"[SERIAL] Sending {len(waypoints)} points to arm")

    for x, y, z, pen in waypoints:

        # convert meters → cm and map to writing plane
        X = x * SCALE
        Y = Y_FIXED + (y * SCALE)

        # limit to reachable workspace
        r = math.sqrt(X**2 + Y**2)
        if r > MAX_R:
            continue

        # pen up/down using Z height
        if pen == 1:
            Z = WRITE_Z
        else:
            Z = LIFT_Z

        t0, t1, t2 = solve_ik(X, Y, Z)
        send_angles(t0, t1, t2)


# ===== CALIBRATION HELPERS =====

def test_point():
    """Move pen to center of paper and touch."""
    init_serial()
    X = 8.0
    Y = Y_FIXED
    Z = WRITE_Z

    t0, t1, t2 = solve_ik(X, Y, Z)
    send_angles(t0, t1, t2)


def test_line():
    """Draw a straight vertical line."""
    init_serial()

    pts = [
        (8.0, Y_FIXED, LIFT_Z),
        (8.0, Y_FIXED, WRITE_Z),
        (8.0, Y_FIXED - 2.0, WRITE_Z),
        (8.0, Y_FIXED - 2.0, LIFT_Z),
    ]

    for X, Y, Z in pts:
        t0, t1, t2 = solve_ik(X, Y, Z)
        send_angles(t0, t1, t2)