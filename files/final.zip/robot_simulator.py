"""
robot_simulator.py — KUKA iiwa draws text flat on the ground.
Lines drawn at EXACT waypoint coords at z=PZ+offset so always visible.
"""
import requests
import time
import threading
import queue
import pybullet as p
import pybullet_data

ESP_IP = "10.133.95.86"   # ← CHANGE THIS
SETTLE_STEPS = 40
STEP_DELAY   = 0.004
SIM_FORCE    = 500
NUM_JOINTS   = 7
EEF_LINK     = 6

LINE_COLOR = [0.0, 0.2, 1.0]   # solid blue
LINE_WIDTH = 8                  # thick — clearly visible

# Paper bounds  (must contain all letter waypoints)
PX0, PX1 =  0.28,  0.58
PY0, PY1 = -0.62,  0.62
PZ        =  0.012   # same as letter_data.PZ
def send_to_esp(base, shoulder, elbow):
    try:
        url = f"http://{ESP_IP}/?b={int(base)}&s={int(shoulder)}&e={int(elbow)}"
        requests.get(url, timeout=0.05)
    except:
        pass
class RobotSimulator:

    def __init__(self):
        self._wq       = queue.Queue()
        self._running  = False
        self._thread   = None
        self._lock     = threading.Lock()
        self._line_ids = []
        self._pen_body = None
        self._robot    = None

    def start(self):
        self._running = True
        self._thread  = threading.Thread(target=self._run, daemon=True)
        self._thread.start()

    def submit_waypoints(self, wps):
        self._wq.put(wps)

    def shutdown(self):
        self._running = False
        if self._thread:
            self._thread.join(timeout=5)

    def _run(self):
        self._setup()
        self._home()
        while self._running:
            try:
                wps = self._wq.get(timeout=0.05)
            except queue.Empty:
                p.stepSimulation()
                time.sleep(STEP_DELAY)
                continue
            self._clear_lines()
            self._draw(wps)
        p.disconnect()

    def _setup(self):
        p.connect(p.GUI)
        p.setAdditionalSearchPath(pybullet_data.getDataPath())
        p.setGravity(0, 0, -9.81)
        p.setRealTimeSimulation(0)
        p.configureDebugVisualizer(p.COV_ENABLE_SHADOWS, 0)
        p.configureDebugVisualizer(p.COV_ENABLE_GUI, 0)

        p.loadURDF("plane.urdf")
        self._robot = p.loadURDF(
            "kuka_iiwa/model.urdf",
            basePosition=[0, 0, 0],
            useFixedBase=True
        )

        # Camera: looking straight down at the paper from above and slightly behind
        # cameraYaw=90 means camera is to the LEFT side, looking right
        # We want: robot at top of view, text below reading left→right
        p.resetDebugVisualizerCamera(
            cameraDistance=1.5,
            cameraYaw=90,       # camera on the side — text reads L→R horizontally
            cameraPitch=-70,    # steep top-down
            cameraTargetPosition=[0.43, 0.0, 0.0]
        )

        # White paper outline
        corners = [
            [PX0, PY0, PZ+0.001], [PX1, PY0, PZ+0.001],
            [PX1, PY1, PZ+0.001], [PX0, PY1, PZ+0.001],
        ]
        for i in range(4):
            p.addUserDebugLine(corners[i], corners[(i+1)%4], [1,1,1], 2)

        # Red pen tip sphere
        vis = p.createVisualShape(p.GEOM_SPHERE, radius=0.016,
                                  rgbaColor=[1, 0.05, 0.05, 1])
        self._pen_body = p.createMultiBody(baseVisualShapeIndex=vis)

    def _ik(self, x, y, z):
        return p.calculateInverseKinematics(
            self._robot, EEF_LINK,
            targetPosition=[x, y, z],
            maxNumIterations=200,
            residualThreshold=1e-4
        )

    def _apply(self, joints, steps):

    # Convert first 3 joints once
        base_angle     = joints[0]
        shoulder_angle = joints[1]
        elbow_angle    = joints[2]

        base_deg     = base_angle * 180 / 3.14159
        shoulder_deg = shoulder_angle * 180 / 3.14159
        elbow_deg    = elbow_angle * 180 / 3.14159

        base_deg     = max(0, min(180, base_deg))
        shoulder_deg = max(0, min(180, shoulder_deg))
        elbow_deg    = max(0, min(180, elbow_deg))

    # 🔵 SEND ONLY ONCE
        send_to_esp(base_deg, shoulder_deg, elbow_deg)

    # Simulation movement
        for _ in range(steps):
            for i, a in enumerate(joints[:NUM_JOINTS]):
                p.setJointMotorControl2(
                    self._robot,
                    i,
                    p.POSITION_CONTROL,
                    targetPosition=a,
                    force=SIM_FORCE
            )

            p.stepSimulation()
            time.sleep(STEP_DELAY)

    def _home(self):
        self._apply([0, -0.5, 0, 1.0, 0, -0.5, 0], steps=100)

    def _draw(self, waypoints):
        prev = None

        for wp in waypoints:
            x, y, z, pen = wp

            # Move arm (lift when pen up to avoid dragging)
            arm_z = z if pen == 1 else z + 0.10
            joints = self._ik(x, y, arm_z)
            self._apply(joints, SETTLE_STEPS)

            # Red sphere follows exactly
            sp_z = z + 0.005 if pen == 1 else z + 0.10
            p.resetBasePositionAndOrientation(
                self._pen_body, [x, y, sp_z], [0,0,0,1]
            )

            # Draw line at EXACT waypoint position — always correct regardless of IK accuracy
            if pen == 1 and prev is not None:
                lid = p.addUserDebugLine(
                    [prev[0], prev[1], PZ + 0.008],   # slightly above ground
                    [x,       y,       PZ + 0.008],
                    LINE_COLOR, LINE_WIDTH
                )
                with self._lock:
                    self._line_ids.append(lid)
            
            prev = [x, y, z]

        self._home()

    def _clear_lines(self):
        with self._lock:
            for lid in self._line_ids:
                try:
                    p.removeUserDebugItem(lid)
                except Exception:
                    pass
            self._line_ids.clear()


_sim = None

def get_simulator() -> RobotSimulator:
    global _sim
    if _sim is None:
        _sim = RobotSimulator()
        _sim.start()
        time.sleep(2.5)
    return _sim

if __name__ == "__main__":
    sim = get_simulator()

    while True:
        text = input("Enter letter to draw: ")

        if text.upper() == "A":
            A_points = [
                [0.4, -0.2, PZ, 1],
                [0.45, 0.2, PZ, 1],
                [0.5, -0.2, PZ, 1],
                [0.425, 0.0, PZ, 1],
                [0.475, 0.0, PZ, 1],
            ]
            sim.submit_waypoints(A_points)